<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'trapdanmark');

/** MySQL database username */
define('DB_USER', 'trapdanmark');

/** MySQL database password */
define('DB_PASSWORD', 'trapdanmark123!');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ZnWWzO1I+w_aE*Mv&G$~hATDwok+^c*#=DKz(^J uivUp[~!%f`X~|,?l`X2G5Xa');
define('SECURE_AUTH_KEY',  'QTtCs7A>1U}`!VjXJM^Z/,*iRPO#R^4HR,k?=XkW|v-~!1rk1+G3t5y|%x|eP(P]');
define('LOGGED_IN_KEY',    'AB5N4r>r9K2jGi:Cq+(LRM!Is(mMy,YWLdiG$-RBJa#AN1f[m-w|w?qn(wciAEQ$');
define('NONCE_KEY',        'fY(-8^}Y `Qt<;Kzu0zJMEll|,oHw|>;)~]onOExp)p>fT4hoc~b#w] )3$oa/QK');
define('AUTH_SALT',        'eiZP?7}4`R9.J#SB H6wHy$D`zIftDFcQBkNnP>K*YlW}nrj|uGa4[6ZQLQW6 n[');
define('SECURE_AUTH_SALT', 't)EAv`%|EO:d5=ya#Z)4?im~0uc:#O{s8qulpi:Q%I#_a`{4iv_I+]=F |N=<p;T');
define('LOGGED_IN_SALT',   'k-CMXPEX59el>2X,i+.5K7PP/*uUi5/(NNMst!-pBF?#/Cm3e!)C|-![|uVY[HCS');
define('NONCE_SALT',       '7Jqh@>Wwpfv/I2+uhQ+AGQMW9a&5+#mIfb?+Rh&){&$:kD&oRFDj,Se*2o]T55Wt');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define ('WPLANG', 'da_DK');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
